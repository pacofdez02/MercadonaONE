package com.mercadona.shopone;

public class MercadonaShopOne {
    Item[] items;

    public MercadonaShopOne(Item[] items) {
        this.items = items;
    }

    public void updateQuality() {

        boolean isCheese, isHam, isSalt, isFrozen, isOther;
        int sellIn;

        for (Item itemActual : items) {

            isCheese = itemActual.name.equals("Aged blue cheese");
            isHam = itemActual.name.equals("Ham");
            isSalt = itemActual.name.equals("Iodized salt");
            isFrozen = itemActual.name.equals("Frozen cake");
            isOther = !isCheese && !isHam && !isSalt && !isFrozen;


            //Salt is irrelevant, we just skip it.
            if (isSalt)
                continue;

            --itemActual.sellIn;
            sellIn = itemActual.sellIn;

            if (isCheese) {
                sumaQuality(itemActual);
                if (sellIn < 0)
                    sumaQuality(itemActual);
            }

            if(isHam){
                sumaQuality(itemActual);
                if (sellIn <= 5)
                    sumaQuality(itemActual,2);
                else if (sellIn <= 10)
                    sumaQuality(itemActual);
            }

            if(isFrozen){
                if (sellIn <= 0)
                    restaQuality(itemActual, 4);
                else
                    restaQuality(itemActual,2);
            }

            if(isOther) {
                if (sellIn <= 0)
                    restaQuality(itemActual);
                restaQuality(itemActual);
            }

            if(QualityToZero(itemActual) && !isCheese)
                itemActual.quality = 0;

        }

    }

    public void sumaQuality(Item item) {
        if (item.quality < 50)
            ++item.quality;
    }
    public void sumaQuality(Item item, int quantity) {
        if (item.quality < 50)
            item.quality += quantity;
    }

    public void restaQuality(Item item) {
        if (item.quality > 0)
            --item.quality;
    }

    public void restaQuality(Item item, int quantity) {
        if (item.quality > 0)
            item.quality -= quantity;
    }

    public boolean QualityToZero(Item item){
        if (item.sellIn <= 0)
            return true;

        return item.quality <= 0;
    }
}


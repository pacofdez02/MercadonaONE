#!/bin/bash

python3 -m venv venv --clear
source venv/bin/activate

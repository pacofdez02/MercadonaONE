#!/bin/bash

./gradlew clean test --info
